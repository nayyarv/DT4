package d4AcceptanceTests;

public interface Test {
   public void run ();
}
